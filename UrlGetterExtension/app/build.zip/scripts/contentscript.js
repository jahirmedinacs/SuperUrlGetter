console.log('Content script');
let topDiv = document.createElement('button');
topDiv.setAttribute('class', 'content-top-div');
topDiv.innerText = 'get All URLs';
topDiv.setAttribute('id', 'clickMeToDownload')
topDiv.setAttribute('onclick', 'DownThemAll()')

document.body.appendChild(topDiv);



